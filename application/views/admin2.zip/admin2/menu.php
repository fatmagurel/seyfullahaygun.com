    <div class="menu">
        <div class="main-menu text-center">
            <div class="scroll">
                <ul class="list-unstyled">
                    <li>
                        <a href="<?=base_url()?>admin2/AdminAna">
                            <i class="iconsminds-shop-4"></i>
                            <span>Anasayfa</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?=base_url()?>admin2/Sitegenel">
                            <i class="iconsminds-digital-drawing"></i> Site Genel Ayarlar
                        </a>
                    </li>
                    <li>
                        <a href="<?=base_url()?>admin2/Portfolyo">
                            <i class="iconsminds-air-balloon-1"></i> Portfolyo
                        </a>
                    </li>
                    <li>
                        <a href="<?=base_url()?>admin2/Hakkimda">
                            <i class="iconsminds-pantone"></i> Hakkımda
                        </a>
                    </li>
                    <li>
                        <a href="<?=base_url()?>admin2/Iletisim">
                            <i class="iconsminds-three-arrow-fork"></i> İletişim
                        </a>
                    </li>
                    <li>
                        <a href="<?=base_url()?>admin2/IletisimFormu">
                            <i class="iconsminds-bucket"></i> Kullanıcı Mesajları
                        </a>
                    </li>
                </ul>
            </div>
        </div>

        <div class="sub-menu">
        </div>
    </div>