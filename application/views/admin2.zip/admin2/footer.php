<script src="<?=base_url()?>assets2/js/vendor/cropper.min.js"></script>
<script src="<?=base_url()?>assets2/js/vendor/jquery-3.3.1.min.js"></script>
<script src="<?=base_url()?>assets2/js/vendor/bootstrap.bundle.min.js"></script>
<script src="<?=base_url()?>assets2/js/vendor/Chart.bundle.min.js"></script>
<script src="<?=base_url()?>assets2/js/vendor/chartjs-plugin-datalabels.js"></script>
<script src="<?=base_url()?>assets2/js/vendor/moment.min.js"></script>
<script src="<?=base_url()?>assets2/js/vendor/fullcalendar.min.js"></script>
<script src="<?=base_url()?>assets2/js/vendor/datatables.min.js"></script>
<script src="<?=base_url()?>assets2/js/vendor/perfect-scrollbar.min.js"></script>
<script src="<?=base_url()?>assets2/js/vendor/owl.carousel.min.js"></script>
<script src="<?=base_url()?>assets2/js/vendor/progressbar.min.js"></script>
<script src="<?=base_url()?>assets2/js/vendor/jquery.barrating.min.js"></script>
<script src="<?=base_url()?>assets2/js/vendor/select2.full.js"></script>
<script src="<?=base_url()?>assets2/js/vendor/bootstrap-datepicker.js"></script>
<script src="<?=base_url()?>assets2/js/vendor/Sortable.js"></script>
<script src="<?=base_url()?>assets2/js/vendor/typeahead.bundle.js"></script>
<script src="<?=base_url()?>assets2/js/dore.script.js"></script>
<script src="<?=base_url()?>assets2/js/scripts.single.theme.js"></script>
<script src="<?=base_url()?>assets2/js/vendor/jquery.contextMenu.min.js"></script>
<script src="<?=base_url()?>assets2/js/scripts.js"></script>
<script src="<?=base_url()?>assets2/js/vendor/bootstrap-tagsinput.min.js"></script>
<script src="<?=base_url()?>assets2/js/vendor/jquery.smartWizard.min.js"></script>
<script src="<?=base_url()?>assets2/js/vendor/baguetteBox.min.js"></script>
<script src="<?=base_url()?>assets2/js/vendor/jquery.autoellipsis.js"></script>
<script src="<?=base_url()?>assets2/js/sweetalert2.min.js"></script>
<script src="<?=base_url()?>assets2/js/vendor/jquery.smartWizard.min.js"></script>
<script src="<?=base_url()?>assets2/js/vendor/jquery.validate/jquery.validate.min.js"></script>
<script src="<?=base_url()?>assets2/js/vendor/jquery.validate/additional-methods.min.js"></script>
<script src="<?=base_url()?>assets2/js/dore-plugins/select.from.library.js"></script>
<script src="<?=base_url()?>assets2/js/scripts.single.theme.js"></script>
</body>

</html>