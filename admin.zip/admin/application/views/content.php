<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12">
              <div class="card">
                <div class="card-body">
					<p>Yönetim Paneline Hoşgeldin &#128035; &#128512;</p>
                </div>
              </div>
             </div>
        </div>
            
    </div>
</div>