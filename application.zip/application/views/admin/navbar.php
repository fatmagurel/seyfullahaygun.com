<div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <a class="navbar-brand" href="javascript:;">Seyfullah Aygün Photography</a>
          </div>
            <a type="button" class="btn btn-danger" href="<?=base_url()?>admin/login/login_cik">ÇIKIŞ</a> 
           
        </div>
      </nav>
      <!-- End Navbar -->